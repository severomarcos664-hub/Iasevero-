# IASevero
Site oficial do projeto IASevero. Deploy automático via GitHub Pages.